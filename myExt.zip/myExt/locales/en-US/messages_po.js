/* auto generated content */
/* lang: en-US */
var langCode = 'en-US';
var i18n_tr = [];