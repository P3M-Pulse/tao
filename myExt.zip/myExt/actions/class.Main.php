<?php
/**
 * @author Bertrand Chevrier, <taosupport@tudor.lu>
 * @package myExt
 * @subpackage actions
 * @license GPLv2  http://www.opensource.org/licenses/gpl-2.0.php
 * 
 */

class myExt_actions_Main extends tao_actions_Main {
	// this class needs to be in place to use the structure.xml	
}
?>